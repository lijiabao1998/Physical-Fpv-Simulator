# Evidence source attribution

Source licenses remain separate. This attribution is not a blanket license for the evidence bundle or original project code. Cited authors and projects do not endorse this analysis. Source paper licenses are not inferred from dataset licenses.

## Catenaro and Onori experimental galvanostatic battery data, version 2

Authors: Edoardo Catenaro; Simona Onori
Attribution basis: Dataset record creator list
Source: https://doi.org/10.17632/kxsbr4x3j2.2
Record: https://data.mendeley.com/datasets/kxsbr4x3j2/2
Related paper: https://doi.org/10.1016/j.dib.2021.106894
License: CC-BY-4.0 (https://creativecommons.org/licenses/by/4.0/)
Changes and use: Original XLSX workbooks are retained unchanged and checked against official file SHA256 digests. Inspection describes every contiguous protocol step. Derived discharge exports preserve the measured step clock and current sign and convert surface temperature from Celsius to Kelvin. No smoothing, initial-SOC fitting, time stretching or inferred points fill the missing start. Derived summaries are not new physical measurements or a validation claim.

## O'Regan et al. thermal-electrochemical parameter measurements

Authors: O'Regan, Kieran; Brosa-Planella, Ferran; Widanage, W. Dhammika; Kendrick, Emma
Attribution basis: Official Zenodo record creator list verified on 2026-10-08.
Source: https://doi.org/10.5281/zenodo.5171874
Record: https://zenodo.org/records/5171874
Related paper: https://doi.org/10.1016/j.electacta.2022.140700
License: CC-BY-4.0 (https://creativecommons.org/licenses/by/4.0/)
Changes and use: Measurement-source provenance for the published ORegan2022 parameterization. The model uses the installed PyBaMM implementation of published functions and corrections; no new parameter fitting is performed. Exports distinguish unchanged source CSV members, declared unit conversions, fixed-function comparisons and derived model outputs. PyBaMM's BSD-3-Clause software license does not replace this data license.

## Software, separately licensed

PyBaMM: Valentin Sulzer; Scott G. Marquis; Robert Timms; Martin Robinson; S. Jon Chapman
Citation: https://doi.org/10.5334/jors.309
License: BSD-3-Clause (https://github.com/pybamm-team/PyBaMM/blob/main/LICENSE.txt)
Software implementation only; measurement-data licenses are listed separately.

Original project code: No license has been selected.
